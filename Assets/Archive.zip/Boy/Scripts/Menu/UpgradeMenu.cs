﻿using UnityEngine;
using System.Collections;

public class UpgradeMenu : MonoBehaviour {

    private PlayerSkillpoints playerSkillpoints;
    private WeaponRotation weaponRotation;
    private PlayerHealth playerHealth;
    private GamePause gamePause;
    public bool hasSkillpoints;
    bool openMenu;

    void Awake() {
        playerSkillpoints = GameObject.FindGameObjectWithTag("PlayerSkillpointsUI").GetComponent<PlayerSkillpoints>();
        weaponRotation = GameObject.FindGameObjectWithTag("Player").GetComponent<WeaponRotation>();
        playerHealth = GameObject.FindGameObjectWithTag("PlayerHealthUI").GetComponent<PlayerHealth>();
    }

    public void OnGUI() {
        if (hasSkillpoints) {
            GUI.Label(new Rect(Screen.width / 2 - 60, Screen.height - 100, 150, 25), "Skillpoints available!");

            if (GUI.Button(new Rect(Screen.width / 2 - 75, Screen.height - 75, 150, 25), "Upgrades")) {
                openMenu = true;

            } else if (openMenu) { 

                // The box everything is in
                GUI.Box(new Rect(Screen.width, Screen.height, -Screen.width, -Screen.height), "");

                // Increases player's fire rate
                if (GUI.Button(new Rect(Screen.width / 2 - 225, Screen.height / 2 - 100, 150, 25), "Fire rate")) {
                    if (weaponRotation.fireRate >= 0.2f) {
                        weaponRotation.fireRate -= 0.1f;
                        playerSkillpoints.IncreaseValue(-1);
                    } else {
                        GUI.Label(new Rect(Screen.width / 2 - 225, Screen.height / 2 - 80, 150, 25), "Maxed out!");
                    }
                }

                // Gives the player health
                if (GUI.Button(new Rect(Screen.width / 2 + 75, Screen.height / 2 - 100, 150, 25), "Extra Health")) {
                    playerHealth.TakeDamage(-50);
                    playerSkillpoints.IncreaseValue(-1);
                }

                // Closes the menu
                if (GUI.Button(new Rect(Screen.width / 2 - 75, Screen.height / 2 - 50, 150, 25), "OK")) {
                    openMenu = false;
                }
            }
        } else {
            openMenu = false;
        }
    }
}
