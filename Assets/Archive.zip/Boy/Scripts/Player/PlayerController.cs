﻿using UnityEngine;
using System.Collections;

public class PlayerController : MonoBehaviour {

    public float jumpVelocity;
    private bool touchingPlatform;

    void Update() {
        if (touchingPlatform && Input.GetButtonDown("Jump")) {
            Debug.Log("jump");
            rigidbody2D.AddForce(new Vector2(0, jumpVelocity));
            touchingPlatform = false;
        }
    }


    // Check if Player is in ground
    void OnCollisionEnter2D() {
        touchingPlatform = true;
        Debug.Log("on collision enter");
    }

    void OnCollisionExit2D() {
        touchingPlatform = false;
        Debug.Log("on collision exit");
    }
}
